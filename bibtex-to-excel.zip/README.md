# BibTeX to Excel Converter (Web App)

Upload a `.bib` file and get an Excel file with selected fields (ID, title, year, journal, and up to 3 authors).

## 🛠️ How to Deploy (on Render)

1. Clone or fork this repo.
2. Create an account at [https://render.com](https://render.com).
3. Click “New Web Service” and connect your GitHub repo.
4. Use these settings:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python app.py`
   - **Runtime:** Python 3.x

## ✅ Features
- Upload `.bib` files
- Extract ID, title, year, journal
- Extract first 3 authors
- Download result as `.xlsx`
