from flask import Flask, request, render_template, send_file
import tempfile
import os
import bibtexparser
import pandas as pd

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        file = request.files['bibfile']
        if not file:
            return "No file uploaded."

        bib_data = file.read().decode('utf-8')
        bib_database = bibtexparser.loads(bib_data)
        entries = bib_database.entries

        data = []
        for entry in entries:
            row = {field: entry.get(field, '') for field in ['ID', 'title', 'year', 'journal']}
            authors = [a.strip() for a in entry.get('author', '').split(' and ') if a.strip()]
            for i in range(3):
                row[f'author_{i+1}'] = authors[i] if i < len(authors) else ''
            data.append(row)

        df = pd.DataFrame(data)
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
        df.to_excel(temp_file.name, index=False)
        temp_file.close()

        return send_file(temp_file.name, as_attachment=True, download_name='output.xlsx')

    return '''
    <form method="POST" enctype="multipart/form-data">
        <p>Upload a .bib file: <input type="file" name="bibfile" /></p>
        <p><input type="submit" value="Convert to Excel" /></p>
    </form>
    '''

if __name__ == '__main__':
    app.run(debug=True)
